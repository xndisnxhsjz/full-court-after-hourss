# Roster snapshot & scope

The game ships with 12 current-era selectable team choices (Boston, New York, Milwaukee, Golden State, the Lakers, Denver, Oklahoma City, Phoenix, Dallas, Philadelphia, Miami and Minnesota), with three representative players for each team. The sample team assignments were checked against the NBA's official 2026 offseason tracker updated October 19, 2026: https://www.nba.com/news/nba-offseason-deals-2026.

This is not the complete 30-team NBA league and does not include every player on any team's roster. Names and player/team assignments are roster references; ratings (80–98-ish overall ratings used by the game) are custom arcade balancing estimates and are not official NBA ratings. The unlockable teams are historical: 2000–01 Lakers, 1995–96 Bulls, 2013–14 Spurs, and 2016–17 Warriors.

Player names, team names, and historical lineup references are used for identification. Game visuals, UI, arena, player illustrations, and sound-free presentation are original generic assets; there are no official league logos, NBA 2K art, or licensed music.
