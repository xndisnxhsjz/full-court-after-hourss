'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { WebSocketServer, WebSocket } = require('ws');
const PORT = Number(process.env.PORT || 3000);
const ROOT = path.join(__dirname, 'public');
const rooms = new Map(), clients = new Map(), queue = [];
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.json':'application/json'};
const server = http.createServer((req,res)=>{
  if(req.url==='/health'){res.writeHead(200,{'content-type':'application/json'});return res.end(JSON.stringify({ok:true,rooms:rooms.size,players:clients.size}));}
  const pathname = decodeURIComponent((req.url||'/').split('?')[0]);
  const rel = pathname==='/'?'index.html':pathname.replace(/^\/+/, '');
  const target = path.resolve(ROOT,rel);
  if(!target.startsWith(ROOT+path.sep) && target!==ROOT){res.writeHead(403);return res.end('Forbidden');}
  fs.readFile(target,(err,data)=>{if(err){res.writeHead(404);return res.end('Not found');}res.writeHead(200,{'content-type':mime[path.extname(target)]||'application/octet-stream','cache-control':'no-cache'});res.end(data);});
});
const wss = new WebSocketServer({server,path:'/ws',maxPayload:16*1024});
const id=()=>crypto.randomBytes(8).toString('hex');
const code=()=>crypto.randomBytes(3).toString('hex').toUpperCase();
const safeName=v=>String(v||'Hooper').replace(/[<>\u0000-\u001f]/g,'').trim().slice(0,18)||'Hooper';
const safeTeam=v=>String(v||'bos').slice(0,24);
function send(ws,obj){if(ws?.readyState===WebSocket.OPEN)ws.send(JSON.stringify(obj));}
function broadcast(room,obj){for(const m of room.members){const c=clients.get(m.id);if(c)send(c.ws,obj);}}
function publicRooms(){return [...rooms.values()].filter(r=>r.public&&r.phase!=='playing').map(r=>({code:r.code,leader:r.members[0]?.name||'PUBLIC ROOM',members:r.members.length}));}
function stateFor(r){return {players:r.players,score:r.score,time:r.time,shotTime:r.shotTime,ball:r.ball,text:r.text,homeTeamId:r.members.find(m=>m.slot===0)?.teamId||'bos',awayTeamId:r.members.find(m=>m.slot===3)?.teamId||'gsw'};}
function roomView(r){return {code:r.code,public:r.public,phase:r.phase,leaderId:r.leaderId,members:r.members.map(m=>({id:m.id,name:m.name,teamId:m.teamId,slot:m.slot,side:m.side,ready:m.ready,connected:!!clients.get(m.id)}))};}
function emitRoom(r){broadcast(r,{type:'roomState',room:roomView(r),member:null,state:r.phase==='playing'?stateFor(r):null});for(const m of r.members){const c=clients.get(m.id);if(c)send(c.ws,{type:'roomState',room:roomView(r),member:{id:m.id,slot:m.slot,side:m.side,ready:m.ready},state:r.phase==='playing'?stateFor(r):null});}}
function leave(c){if(!c.roomCode)return;const r=rooms.get(c.roomCode);c.roomCode=null;if(!r)return;r.members=r.members.filter(m=>m.id!==c.id);if(!r.members.length)rooms.delete(r.code);else{if(r.leaderId===c.id)r.leaderId=r.members[0].id;r.members.forEach((m,i)=>{m.slot=i;m.side=i<3?0:1});emitRoom(r);}send(c.ws,{type:'roomLeft',message:'You left the party.'});}
function makePlayers(r){return Array.from({length:6},(_,slot)=>{const m=r.members.find(x=>x.slot===slot);return {id:m?.id||`ai-${slot}`,slot,teamId:m?.teamId||(slot<3?r.members[0]?.teamId:'gsw'),x:slot<3?250+slot*45:750-(slot-3)*45,y:180+slot%3*110,stamina:100,color:slot<3?'#42d8ff':'#a16dff',trail:'trail_none'};});}
function startMatch(r){if(r.phase==='playing')return;r.phase='playing';r.score=[0,0];r.time=300;r.shotTime=14;r.ball={x:500,y:300,owner:0,flight:0};r.text='TIP OFF';r.players=makePlayers(r);r.lastTick=Date.now();broadcast(r,{type:'matchStart',room:roomView(r),state:stateFor(r)});}
function tick(){const now=Date.now();for(const r of rooms.values()){if(r.phase!=='playing')continue;const dt=Math.min(.2,(now-(r.lastTick||now))/1000);r.lastTick=now;r.time=Math.max(0,r.time-dt);r.shotTime=Math.max(0,r.shotTime-dt);for(const m of r.members){const c=clients.get(m.id);const p=r.players[m.slot];if(c&&c.input&&p){p.x=Math.max(30,Math.min(970,p.x+(c.input.dx||0)*dt*180*(c.input.sprint?1.35:1)));p.y=Math.max(50,Math.min(550,p.y+(c.input.dy||0)*dt*180*(c.input.sprint?1.35:1)));p.stamina=Math.max(10,p.stamina-(c.input.sprint?dt*12:-dt*6));}}
    if(r.shotTime<=0){r.shotTime=14;r.ball.owner=(r.ball.owner+3)%6;r.text='SHOT CLOCK VIOLATION';}
    if(Math.random()<dt*.22){const shooter=r.ball.owner||0;const side=shooter<3?0:1;const chance=.22+(r.members.find(m=>m.slot===shooter)?.shootBonus||0);if(Math.random()<chance){r.score[side]+=Math.random()<.22?3:2;r.text=Math.random()<.25?'FROM DOWNTOWN!':'BUCKET!';r.ball.owner=(shooter+3)%6;r.shotTime=14;}}
    if(r.time<=0){r.phase='finished';const winnerSide=r.score[0]===r.score[1]?-1:r.score[0]>r.score[1]?0:1;broadcast(r,{type:'matchEnd',state:stateFor(r),result:{winnerSide}});continue;}
    if(now-(r.lastBroadcast||0)>80){r.lastBroadcast=now;broadcast(r,{type:'matchState',state:stateFor(r)});}
  }}
setInterval(tick,50).unref();
wss.on('connection',(ws)=>{const c={id:id(),ws,roomCode:null,input:{dx:0,dy:0}};clients.set(c.id,c);send(ws,{type:'welcome',clientId:c.id});ws.on('message',raw=>{let m;try{m=JSON.parse(raw.toString())}catch{return}if(!m||typeof m.type!=='string')return;
  if(m.type==='hello'){c.name=safeName(m.name);c.teamId=safeTeam(m.teamId);send(ws,{type:'profile',name:c.name});}
  else if(m.type==='createParty'||m.type==='createPublicParty'){if(c.roomCode)leave(c);let roomCode;do{roomCode=code()}while(rooms.has(roomCode));const r={code:roomCode,public:m.type==='createPublicParty',phase:'lobby',leaderId:c.id,members:[],score:[0,0],time:300,shotTime:14,ball:{x:500,y:300,owner:0,flight:0},players:[]};rooms.set(roomCode,r);addMember(c,r,m);emitRoom(r);}
  else if(m.type==='joinParty'){const r=rooms.get(String(m.code||'').toUpperCase());if(!r)return send(ws,{type:'error',message:'Party code not found.'});if(r.phase==='playing'||r.members.length>=6)return send(ws,{type:'error',message:'That party is full or already playing.'});if(c.roomCode)leave(c);addMember(c,r,m);emitRoom(r);}
  else if(m.type==='rejoin'){const r=rooms.get(String(m.roomCode||'').toUpperCase());if(r&&r.members.some(x=>x.id===c.id)){c.roomCode=r.code;emitRoom(r);}}
  else if(m.type==='ready'){const r=rooms.get(c.roomCode);const me=r?.members.find(x=>x.id===c.id);if(me){me.ready=!!m.ready;emitRoom(r);}}
  else if(m.type==='selectTeam'||m.type==='updateLoadout'){const r=rooms.get(c.roomCode);const me=r?.members.find(x=>x.id===c.id);if(me&&m.type==='selectTeam')me.teamId=safeTeam(m.teamId);if(r)emitRoom(r);}
  else if(m.type==='startMatch'){const r=rooms.get(c.roomCode);if(!r||r.leaderId!==c.id)return send(ws,{type:'error',message:'Only the party leader can start.'});startMatch(r);}
  else if(m.type==='leaveParty'){leave(c);}
  else if(m.type==='input'){c.input={dx:Math.max(-1,Math.min(1,Number(m.dx)||0)),dy:Math.max(-1,Math.min(1,Number(m.dy)||0)),sprint:!!m.sprint};}
  else if(m.type==='listPublic')send(ws,{type:'publicRooms',rooms:publicRooms()});
  else if(m.type==='quickMatch'){if(c.roomCode)leave(c);let r=[...rooms.values()].find(x=>x.public&&x.phase==='lobby'&&x.members.length<6);if(!r){const roomCode=code();r={code:roomCode,public:true,phase:'lobby',leaderId:c.id,members:[],score:[0,0],time:300,shotTime:14,ball:{x:500,y:300,owner:0,flight:0},players:[]};rooms.set(roomCode,r);}addMember(c,r,m);emitRoom(r);send(ws,{type:'queueStatus',active:true,message:'Joined public matchmaking room.'});if(r.members.length>=2)startMatch(r);}
  else if(m.type==='cancelQueue')leave(c);
 });ws.on('close',()=>{const r=rooms.get(c.roomCode);if(r){const member=r.members.find(m=>m.id===c.id);if(member)member.connected=false;setTimeout(()=>{if(!clients.has(c.id)){const rr=rooms.get(r.code);if(rr){rr.members=rr.members.filter(m=>m.id!==c.id);if(!rr.members.length)rooms.delete(rr.code);else{if(rr.leaderId===c.id)rr.leaderId=rr.members[0].id;emitRoom(rr);}}}},15000);}clients.delete(c.id);});
});
function addMember(c,r,m){if(r.members.length>=6)return send(c.ws,{type:'error',message:'Party is full.'});const slot=r.members.length;c.name=safeName(m.name||c.name);c.teamId=safeTeam(m.teamId||c.teamId);c.roomCode=r.code;r.members.push({id:c.id,name:c.name,teamId:c.teamId,slot,side:slot<3?0:1,ready:false});}
server.listen(PORT,'0.0.0.0',()=>console.log(`FULL COURT: AFTER HOURS running on http://localhost:${PORT}`));
