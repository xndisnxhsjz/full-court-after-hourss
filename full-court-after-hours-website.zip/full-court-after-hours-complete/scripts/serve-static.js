'use strict';
// Zero-dependency local web server for the browser-playable game.
// Run with `npm run web`; online rooms require the full server (`npm start`).
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const ROOT = path.resolve(__dirname, '..', 'public');
const PORT = Number(process.env.PORT || 4173);
const MIME = { '.html':'text/html; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.css':'text/css; charset=utf-8', '.png':'image/png', '.svg':'image/svg+xml', '.json':'application/json' };
http.createServer((req, res) => {
  const pathname = decodeURIComponent((req.url || '/').split('?')[0]);
  if (pathname === '/health') { res.writeHead(200, {'content-type':'application/json'}); return res.end(JSON.stringify({ok:true,mode:'static'})); }
  if (pathname === '/ws') { res.writeHead(426, {'content-type':'text/plain; charset=utf-8'}); return res.end('Online rooms require `npm start` with the WebSocket dependency installed.'); }
  const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const target = path.resolve(ROOT, relative);
  if (target !== ROOT && !target.startsWith(ROOT + path.sep)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(target, (err, data) => {
    if (err) { res.writeHead(err.code === 'ENOENT' ? 404 : 500, {'content-type':'text/plain; charset=utf-8'}); return res.end(err.code === 'ENOENT' ? 'Not found' : 'Server error'); }
    res.writeHead(200, {'content-type':MIME[path.extname(target)] || 'application/octet-stream', 'cache-control':'no-cache', 'x-content-type-options':'nosniff'});
    res.end(data);
  });
}).listen(PORT, '0.0.0.0', () => console.log(`FULL COURT: AFTER HOURS web build running at http://localhost:${PORT}`));
