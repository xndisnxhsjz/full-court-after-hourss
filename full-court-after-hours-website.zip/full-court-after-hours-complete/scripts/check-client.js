const fs = require('node:fs');
const vm = require('node:vm');
const html = fs.readFileSync('public/index.html','utf8');
const scripts = [...html.matchAll(/<script(?:\s[^>]*)?>([\s\S]*?)<\/script>/g)].map(m=>m[1]);
if (!scripts.length) throw new Error('No inline client scripts found');
for (const [i,script] of scripts.entries()) new vm.Script(script,{filename:`inline-${i}.js`});
console.log(`Client syntax OK (${scripts.length} inline scripts).`);
