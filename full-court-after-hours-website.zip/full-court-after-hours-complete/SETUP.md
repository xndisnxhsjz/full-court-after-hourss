# Setup and deployment

## Local game

1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Run `npm test` to syntax-check the project.
4. Run `npm start` and open http://localhost:3000.

## Multiplayer server

The included Node server serves the game and a WebSocket endpoint at `/ws`. For LAN testing, open the host computer's LAN IP on port 3000 from another device, if the firewall permits it. For players on different networks, deploy the project to a host that supports long-lived WebSocket connections and use its HTTPS URL. Test with separate browser sessions before inviting friends.

**Limitations:** this is an early multiplayer scaffold, not a finished competitive online mode. Server simulation and client synchronization need substantial gameplay work and multi-client QA before public launch. Room state is in memory and is lost on restart. Use rate limiting, persistent storage, authenticated identities and abuse protection before public use.

## Google sign-in

Google sign-in is not wired up in this package. To enable it, a Firebase project must be created and configured, then the client must load Firebase Authentication and a secure per-user cloud-save integration must be implemented and tested. The standalone file intentionally does not claim Google authentication is active. Never put service-account keys or other private secrets in browser code.

## Before public launch

- Complete and test the online authoritative game simulation and action validation.
- Add persistent account/profile storage and verified identity to server sockets.
- Add rate limiting, origin allowlists, logging and room cleanup.
- Run end-to-end gameplay tests on desktop, mobile and six separate clients.
- Configure hosting and Google authentication under accounts controlled by the project owner.
