# QA status — FULL COURT: AFTER HOURS

## Verified in the development environment
- `npm test`: passed (server syntax and both inline browser scripts parsed).
- Zero-dependency local web server: `/` returns the game HTML and `/health` returns `{ "ok": true, "mode": "static" }`.
- Headless-browser smoke test with JavaScript enabled: page loaded with 16 team cards; Quick Play opened Squad Select; Customize opened Inventory; an owned cosmetic equipped and showed confirmation; Tip Off opened the game canvas; the match clock advanced from 5:00 to 4:57.
- Mobile viewport smoke test at 390×844: no horizontal page overflow.
- The iPhone Files preview is not a valid way to test this site because it may block script execution. The app must be opened through a browser URL served over HTTP/HTTPS.

## Not verified / not finished
- Full physical-device gameplay QA of movement, shooting, passing, steals, blocks, scoring, win/loss rewards and rematches.
- Six-client online multiplayer and public matchmaking on a deployed host.
- Google sign-in and cloud saves; Firebase project setup and credentials are not available.
- Public deployment; it requires an authorized hosting account/repository. No public URL is being claimed.

## What this is
A runnable web-game project with a browser-served local 3v3 game, player customization/progression, and a WebSocket room-server scaffold. It is not yet a verified production online service.
