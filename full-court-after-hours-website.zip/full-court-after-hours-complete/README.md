# FULL COURT: AFTER HOURS

A responsive browser-based 3-on-3 arcade basketball game. The website is served over HTTP by the included Node server; **do not open `public/index.html` in the iPhone Files preview**, because that preview may not execute JavaScript. Use a browser URL served by a web host instead.

## Play locally on a computer

1. Install Node.js 20 or newer.
2. Open a terminal in this folder.
3. For the local game with no dependency install, run `npm run web` and open `http://localhost:4173`. Local Quick Play and Customize work; online rooms intentionally show that the WebSocket server is not running.
4. For the full app including the online-room server, run `npm install`, then `npm test`, then `npm start` and open `http://localhost:3000` in a browser.

The `/` route serves the game and `/health` reports server status. The WebSocket endpoint is `/ws`.

## Publish as a real website

This repository includes `render.yaml` for Render Blueprint deployment. Push this folder to a GitHub repository, then in Render choose **New → Blueprint**, select that repository, and deploy. Render installs the `ws` dependency and runs the Node server; the generated `https://…onrender.com` address is the public website. The first deployment can take several minutes. A hosting account and an authorized repository connection are required; this package itself does not contain a public URL.

Use a persistent WebSocket-capable Node host for the online lobby. A static-only host can run the local game but cannot run the included party server.

## Controls

- Move: WASD or arrow keys
- Shoot: hold and release Space
- Pass: J
- Steal: K
- Block: L
- Sprint: Shift
- Switch player: Tab
- Pause: Esc
- Touch controls: on-screen joystick and action buttons

## Features in this build

- Local 3-on-3 game against AI, with live score/clock, shooting, passing, steals, blocks, stamina, player switching and match-end rewards.
- Squad selection, difficulty and match length.
- Player customization/inventory, equipment and progression saved in local browser storage.
- Online room creation, room codes, public-room listing and matchmaking scaffold over WebSockets.

## Honest limitations

- Online mode is an early server-side room/game simulation, **not a production-ready six-human competitive basketball implementation**. It needs deeper action synchronization, authoritative basketball rules, reconnect testing, abuse protection and testing with six real clients before being described as complete online 3v3.
- Google sign-in/cloud saves require a Firebase project, authorized domain, public client config and tested auth/cloud-save integration. Those credentials and account setup were not supplied, so Google authentication is not enabled.
- Team names and ratings are curated arcade data, not a licensed official NBA database. Art is original; there are no licensed team logos or music.

## QA status

`npm test` checks server and inline browser JavaScript syntax. A headless-browser smoke test of the served page was also run in the development environment: it loaded the page, switched to Squad Select via Quick Play, opened Customize, started a match with Tip Off, and confirmed the in-game clock advanced. This smoke test does not replace testing on a real phone/desktop or the six-client online test.
